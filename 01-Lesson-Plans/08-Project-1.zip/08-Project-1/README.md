# Unit 8 - Project 1

## Overview

This week is all project work days and Project 1 Presentations.

- - -

### Copyright

Trilogy Education Services © 2018. All Rights Reserved.
